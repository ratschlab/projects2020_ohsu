#!/bin/bash

python3 ../run-search.py allRuns_breast.txt /home/bmx8177/projects/ohsu-eth-collab/CPTAC_filenames_BRCA.txt /home/bmx8177/projects/ohsu-eth-collab/data/mgf ../../20230713-tide-index >log.txt
